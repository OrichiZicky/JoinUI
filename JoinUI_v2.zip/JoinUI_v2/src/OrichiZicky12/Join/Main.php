<?php

namespace OrichiZicky12\Join;

use pocketmine\Server;
use pocketmine\Player;

use pocketmine\plugin\PluginBase;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;

class Main extends PluginBase implements Listener {
	
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		
		 @mkdir($this->getDataFolder());
		 $this->saveDefaultConfig();
		 $this->getResource("config.yml");
	}
	
	public function onJoin(PlayerJoinEvent $event){
		$player = $event->getPlayer();
		
		$this->openMyForm($player);
	}
	
	public function openMyForm(Player $sender){
	    $formapi = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $formapi->createSimpleForm(function (Player $sender, ?int $data = null){
		$result = $data;
		if($result ===  null){
			return;
		    }
			switch($result){
				case 0:
				$sender->addTitle($this->getConfig()->get("Title"), $this->getConfig()->get("Subtitle"));
				break;
			}
		});
		$form->setTitle("§l§f[§r§bEnder§3MC§l§f]");
		$form->setContent("§bWelcome To§l§f[§r§bEnder§3MC§l§f]§r\n§l§f[§r§bEnder§3MC§l§f]§r Season 3 Category Roleplay PVP All Map§r\n§b Have fun playing§r\n§bFacebook : EnderMC Season III§r\n§bThank You For Join My Server ");
		$form->addButton("§l§cEXIT\n§r§dClick to close...",0,"textures/ui/cancel");
		$form->sendToPlayer($sender);
			return $form;
	}
}